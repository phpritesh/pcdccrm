<footer class="main-footer">
    <div class="pull-right">
        <!-- Don't remove below text. It's violate the license. -->
       
    </div>
    <strong>Copyright &copy; {{date('Y')}}  All rights
    reserved.
</footer>