<!-- Master page  -->


<!-- Page title -->
<?php $__env->startSection('pageTitle'); ?> Login <?php $__env->stopSection(); ?>
<!-- End block -->

<!-- Page body extra class -->
<?php $__env->startSection('bodyCssClass'); ?> login-page <?php $__env->stopSection(); ?>
<!-- End block -->

<!-- BEGIN PAGE CONTENT-->
<?php $__env->startSection('pageContent'); ?>

    <?php if(Session::has('success') || Session::has('error') || Session::has('warning')): ?>
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="alert <?php if(Session::has('success')): ?> alert-success <?php elseif(Session::has('error')): ?> alert-danger <?php else: ?> alert-warning <?php endif; ?> alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php if(Session::has('success')): ?>
                        <h5><i class="icon fa fa-check"></i><?php echo e(Session::get('success')); ?></h5>
                    <?php elseif(Session::has('error')): ?>
                        <h5><i class="icon fa fa-ban"></i><?php echo e(Session::get('error')); ?></h5>
                    <?php else: ?>
                        <h5><i class="icon fa fa-warning"></i><?php echo e(Session::get('warning')); ?></h5>
                        <?php endif; ?>
                        </h5>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="login-box">
        <div class="login-logo">
            <a href="/">
                <img src="<?php if(isset($appSettings['crm_settings']['logo'])): ?> <?php echo e(asset('storage/logo/'.$appSettings['crm_settings']['logo'])); ?> <?php else: ?> <?php echo e(asset('images/logo-lg.png')); ?> <?php endif; ?>" alt="">
            </a>
        </div>
        <div class="login-box-body">
            <p class="login-box-msg text-danger">Use your username and password to Login</p>
            <form novalidate id="loginForm" action="<?php echo e(URL::Route('login')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group has-feedback">
                    <input autofocus type="text" class="form-control" name="username" placeholder="username" required minlength="5" maxlength="255">
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="password" placeholder="Password" required minlength="6" maxlength="255">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>

                </div>

                <div class="row">
                    <div class="col-xs-6">
                        <div class="checkbox icheck">
                            <label>
                                <input name="remember" type="checkbox"> Remember Me
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-6">
                        <a href="<?php echo e(URL::Route('forgot')); ?>" class="forgot-link">Forgot Password</a>
                    </div>
                    <!-- /.col -->
                </div>
                <br>
                <button type="submit" class="btn btn-lg btn-block btn-flat login-button">SIGN IN</button>
            </form>


        </div>
        <!-- /.login-box-body -->
    </div>
<?php $__env->stopSection(); ?>
<!-- END PAGE CONTENT-->

<!-- BEGIN PAGE JS-->
<?php $__env->startSection('extraScript'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            Login.init();
        });

    </script>
<?php $__env->stopSection(); ?>
<!-- END PAGE JS-->

<?php echo $__env->make('backend.layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/user/login.blade.php ENDPATH**/ ?>