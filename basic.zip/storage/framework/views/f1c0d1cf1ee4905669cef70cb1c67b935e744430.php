<?php if(Session::has('alertError')): ?>
<div class="alert alert-danger alert-dismissible"> <a aria-label="Close " data-dismiss="alert" class="closed pull-right fa fa-times"></a><?php echo e(Session::get('alertError')); ?></div>
<?php endif; ?>
 
<?php if(Session::has('alertSuccess')): ?>
<div class="alert alert-success alert-dismissible"><a aria-label="Close " data-dismiss="alert" class="closed pull-right fa fa-times"></a><?php echo e(Session::get('alertSuccess')); ?></div>
<?php endif; ?>
 
<?php if(Session::has('alertWarning')): ?>
<div class="alert alert-info alert-dismissible"><a aria-label="Close " data-dismiss="alert" class="closed pull-right fa fa-times"></a><?php echo e(Session::get('alertWarning')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/partial/_alerts.blade.php ENDPATH**/ ?>