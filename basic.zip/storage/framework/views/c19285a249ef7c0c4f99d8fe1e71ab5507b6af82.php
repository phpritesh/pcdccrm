<footer class="main-footer">
    <div class="pull-right">
        <!-- Don't remove below text. It's violate the license. -->
       
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?>  All rights
    reserved.
</footer><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/partial/footer.blade.php ENDPATH**/ ?>