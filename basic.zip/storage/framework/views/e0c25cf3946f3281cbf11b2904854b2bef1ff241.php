<!-- Master page  -->


<!-- Page title -->
<?php $__env->startSection('pageTitle'); ?> 404 <?php $__env->stopSection(); ?>
<!-- End block -->


<!-- BEGIN PAGE CONTENT-->
<?php $__env->startSection('pageContent'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="error-page">
            <h2 class="headline text-yellow">404</h2>
            <div class="error-content">
                <h3><i class="fa fa-warning text-yellow"></i> Oops! Page not found.</h3>
                <p>
                    We could not find the page you were looking for.<br>
                    Meanwhile, you may <a href="/">return to home</a>
                </p>
            </div>
        </div>
        <!-- /.error-page -->

    </section>
    <!-- ./content -->
<?php $__env->stopSection(); ?>
<!-- END PAGE CONTENT-->
<?php echo $__env->make('backend.layouts.error_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/errors/404.blade.php ENDPATH**/ ?>