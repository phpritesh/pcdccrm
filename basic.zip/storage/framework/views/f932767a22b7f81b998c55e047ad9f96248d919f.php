
<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
  <section class="sidebar">
    <!-- sidebar menu -->
    <ul class="sidebar-menu" data-widget="tree">
      <li>
        <a href="<?php echo e(URL::route('user.dashboard')); ?>">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>
     
	  
	 <li class="treeview">
        <a href="#">
         <i class="fa fa-university" aria-hidden="true"></i>
          <span>Data Management</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
		  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('CrmData.list')): ?>
            <li>
              <a href="<?php echo e(URL::route('CrmData.list')); ?>">
                <i class="fa fa-cubes"></i> <span>Crm Data List </span>
              </a>
            </li>
          <?php endif; ?>
		  
		    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('CrmData.assignrequestlist')): ?>
            <li>
              <a href="<?php echo e(URL::route('CrmData.assignrequestlist')); ?>">
                <i class="fa fa-cubes"></i> <span>Data Assign Request List</span>
              </a>
            </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dataimport.index')): ?>
            <li>
              <a href="<?php echo e(URL::route('dataimport.index')); ?>">
                <i class="fa fa-cubes"></i> <span>Data Import List </span>
              </a>
            </li>
          <?php endif; ?>
		  
		   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dataimport.create')): ?>
            <li>
              <a href="<?php echo e(URL::route('dataimport.create')); ?>">
                <i class="fa fa-cubes"></i> <span>Data Import </span>
              </a>
            </li>
          <?php endif; ?>
		  
		 
        </ul>
      </li>
     
    
      <li class="treeview">
        <a href="#">
          <i class="fa fa-user-secret"></i>
          <span>Administrator</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.index')): ?>
        <li>
          <a href="<?php echo e(URL::route('user.index')); ?>">
            <i class="fa fa-users"></i> <span>Users</span>
          </a>
        </li>
        <?php endif; ?>
        
        </ul>
      </li>
   
     
        
      



      <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')) : ?>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-cogs"></i>
          <span>Settings</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <li>
            <a href="<?php echo e(URL::route('settings.crm')); ?>">
              <i class="fa fa-building"></i> <span>CRM</span>
            </a>
          </li>
        
          <li>
            <a href="<?php echo e(route('administrator.user_password_reset')); ?>">
              <i class="fa fa-eye-slash"></i> <span>Reset User Password</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(URL::route('user.role_index')); ?>">
              <i class="fa fa-users"></i> <span>Role</span>
            </a>
          </li>

         
        </ul>
      </li>
      <?php endif; ?>
	  
	  
	   <li class="treeview">
        <a href="#">
         <i class="fa fa-university" aria-hidden="true"></i>
          <span>Masters Management</span>
          <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('industry.index')): ?>
            <li>
              <a href="<?php echo e(URL::route('industry.index')); ?>">
                <i class="fa fa-cubes"></i> <span>Industry </span>
              </a>
            </li>
          <?php endif; ?>
		  
		   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subindustry.index')): ?>
            <li>
              <a href="<?php echo e(URL::route('subindustry.index')); ?>">
                <i class="fa fa-cubes"></i> <span>Sub Industry </span>
              </a>
            </li>
          <?php endif; ?>
		  
		   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('incomegroup.index')): ?>
            <li>
              <a href="<?php echo e(URL::route('incomegroup.index')); ?>">
                <i class="fa fa-cubes"></i> <span>Income Group </span>
              </a>
            </li>
          <?php endif; ?>
        </ul>
      </li>

    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/partial/leftsidebar.blade.php ENDPATH**/ ?>