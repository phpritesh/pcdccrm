<script>
    window.show_language = <?php echo e($show_language); ?>;
</script>
<!-- Control Sidebar -->
<aside  class="control-sidebar control-sidebar-dark">
    <div id="rightSideBarContent">

    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/partial/rightsidebar.blade.php ENDPATH**/ ?>