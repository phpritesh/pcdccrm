<!-- Master page  -->


<!-- Page title -->
<?php $__env->startSection('pageTitle'); ?> Reset User Password <?php $__env->stopSection(); ?>
<!-- End block -->

<!-- Page body extra class -->
<?php $__env->startSection('bodyCssClass'); ?> <?php $__env->stopSection(); ?>
<!-- End block -->

<!-- BEGIN PAGE CONTENT-->
<?php $__env->startSection('pageContent'); ?>
    <!-- Main content -->
    <section class="content-header">
        <h1>
            Data Import
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::route('user.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data import</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <!-- Change password -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Import Crm Data</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <form novalidate id="import-crmdata" action="<?php echo e(URL::route('dataimport.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
							<div class="row">
		<div class="col-md-12 mt15">
		    <label for="userfile">Upload crmdata Excel File :</label>
		    <input style="display: inline " type="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" name="crmdatafile" id="usersfile">
		    <div class="text-danger">( Excel Size must be less than 10 mb)</div>
		</div>
		</div>
                         
                            <br>
                     
                            <button type="submit" class="btn btn-info pull-right submit-button"><i class="fa fa-upload"></i> Import</button>
                        </form>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
                <div class="col-md-3"></div>

                <!-- /.box -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<!-- END PAGE CONTENT-->

<!-- BEGIN PAGE JS-->
<?php $__env->startSection('extraScript'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            Crmdata.Init();
        });
    </script>
<?php $__env->stopSection(); ?>
<!-- END PAGE JS-->

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/crmdata/import.blade.php ENDPATH**/ ?>