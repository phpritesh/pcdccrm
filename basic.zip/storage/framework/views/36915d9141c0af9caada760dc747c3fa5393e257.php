<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name = "viewport">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title><?php if(isset($appSettings['crm_settings']['short_name'])): ?><?php echo e($appSettings['crm_settings']['short_name']); ?> <?php else: ?> Laravel <?php endif; ?> | <?php echo $__env->yieldContent('pageTitle'); ?></title>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,500,700,800' rel='stylesheet' type='text/css'>
	 
		<!-- Bootstrap and Font Awesome css -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<link rel="shortcut icon" href="<?php echo e($appSettings['crm_settings'] ? asset('storage/logo/'.$appSettings['crm_settings']['favicon']) : ""); ?>" type="image/x-icon">

	 <!-- app CSS -->
     	 <link href="<?php echo e(asset(mix('lmix/css/pace.css'))); ?>" rel="stylesheet" type="text/css">
	 <link href="<?php echo e(asset(mix('lmix/css/vendor.css'))); ?>" rel="stylesheet" type="text/css">
	 <link href="<?php echo e(asset(mix('lmix/css/theme.css'))); ?>" rel="stylesheet" type="text/css">
    <script>
        var hash = '<?php echo e(session('user_session_sha1')); ?>';
    </script>
   <!-- Child Page css goes here  -->
   <style>
   .swal2-content{font-size:18px !important;}
   </style>
<?php echo $__env->yieldContent("extraStyle"); ?>
<!-- Child Page css -->
</head>

<body  class="sidebar-mini skin-blue-light <?php echo $__env->yieldContent('bodyCssClass'); ?>" >

<div class="ajax-loader">
    <img class="loader2" src="<?php echo e(asset('/images/loader.svg')); ?>" alt="">
</div>

<!-- Site wrapper -->
<div class="wrapper">
    <!-- page header -->
<?php echo $__env->make('backend.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- / page header -->

    <!-- page aside left side bar -->
<?php echo $__env->make('backend.partial.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- / page aside left side bar -->
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Message -->
        <?php if(Session::has('success') || Session::has('error') || Session::has('warning')): ?>
            <div class="alert custom_alert <?php if(Session::has('success')): ?> alert-success <?php elseif(Session::has('error')): ?> alert-danger <?php else: ?> alert-warning <?php endif; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php if(Session::has('success')): ?>
                    <h5><i class="icon fa fa-check"></i><?php echo Session::get('success'); ?> </h5>
                <?php elseif(Session::has('error')): ?>
                    <h5><i class="icon fa fa-ban"></i><?php echo Session::get('error'); ?> </h5>
                <?php else: ?>
                    <h5><i class="icon fa fa-warning"></i><?php echo Session::get('warning'); ?> </h5>
                    <?php endif; ?>
                    </h5>
            </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
            <div class="alert  alert-success keepIt">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h5 style="font-weight: bold; font-size: large;"><i class="icon fa fa-check"></i><?php echo Session::get('message'); ?> </h5>
            </div>
    <?php endif; ?>
    <!-- ./Message -->
        <!-- BEGIN CHILD PAGE-->
		 <?php echo $__env->make('backend.partial._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('pageContent'); ?>
    <!-- END CHILD PAGE-->
    </div>
    <!-- /.content-wrapper -->

    <!-- footer -->
<?php echo $__env->make('backend.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- / footer -->

    <!-- page aside right side bar -->
<?php echo $__env->make('backend.partial.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- / page aside right side bar -->
   <div id="modal-placeholder"></div>
	<p id="overlay" class="text-center load-overlay"  >
	    <i class="fa fa-spinner fa-pulse fa-5x"></i>
	</p>
</div>
<!-- ./wrapper -->
    
<!-- webpack menifest js -->
<script src="<?php echo e(asset(mix('/lmix/js/manifest.js'))); ?>"></script>
<!-- vendor libaries js -->
<script src="<?php echo e(asset(mix('/lmix/js/vendor.js'))); ?>"></script>
<!-- theme js -->
<script src="<?php echo e(asset(mix('/lmix/js/theme.js'))); ?>"></script>
<!-- app js -->
<script src="<?php echo e(asset(mix('/lmix/js/app.js'))); ?>"></script>
 
<!-- Extra js from child page -->
<?php echo $__env->yieldContent("extraScript"); ?>
<!-- END JAVASCRIPT -->
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>