<!-- Master page  -->


<!-- Page title -->
<?php $__env->startSection('pageTitle'); ?> User <?php $__env->stopSection(); ?>
<!-- End block -->

<!-- Page body extra class -->
<?php $__env->startSection('bodyCssClass'); ?> <?php $__env->stopSection(); ?>
<!-- End block -->

<!-- BEGIN PAGE CONTENT-->
<?php $__env->startSection('pageContent'); ?>
    <!-- Section header -->
    <section class="content-header">
        <h1>
            Data 
            <small>List</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::route('user.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Add New</li>
        </ol>
    </section>
    <!-- ./Section header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header">
                        
						<?php echo Form::open(['route' => 'CrmData.list', 'method'=>'get']); ?>

						<div class="row mt20">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Unique Code Contacts</label>
                                        <input  type="text" class="form-control" name="unique_code_contacts" value="<?php echo e(request()->get('unique_code_contacts') ? request()->get('unique_code_contacts') : ''); ?>" placeholder="Unique Code Contacts"   >
                                       
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Partner Name</label>
                                        <input  type="text" class="form-control" name="partner_name" value="<?php echo e(request()->get('partner_name') ? request()->get('partner_name') : ''); ?>" placeholder="Partner Name"   >
                                       
                                    </div>
                                </div>
								 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Organization Name</label>
                                        <input  type="text" class="form-control" name="organization_name" value="<?php echo e(request()->get('organization_name') ? request()->get('organization_name') : ''); ?>" placeholder="Organization Name"   >
                                       
                                    </div>
                                </div>
								
								 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Domain</label>
                                        <input  type="text" class="form-control" name="domain" value="<?php echo e(request()->get('domain') ? request()->get('domain') : ''); ?>" placeholder="Domain"   >
                                       
                                    </div>
                                </div>
						</div>
						<div class="row mt10">
						 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Cloud Provider</label>
                                        <input  type="text" class="form-control" name="cloud_provider" value="<?php echo e(request()->get('cloud_provider') ? request()->get('cloud_provider') : ''); ?>" placeholder="Cloud Provider"   >
                                      
                                    </div>
                                </div>
						   <div class="col-md-3">
                                   <div class="form-group">
                                        <label for="name">Industry Vertical</label>
										 <?php echo Form::select('industry_vertical', $industry, request()->get('industry_vertical') ? request()->get('industry_vertical') : '' , ['placeholder' => 'Pick Industry Vertical','class' => 'form-control select2']); ?>

                                       
                                    </div>
                          </div>
						  
						   <div class="col-md-3">
                                   <div class="form-group">
                                        <label for="name">Sub Vertical</label>
										 <?php echo Form::select('sub_vertical', $sub_vertical, request()->get('sub_vertical') ? request()->get('sub_vertical') : '' , ['placeholder' => 'Pick Sub Vertical Vertical','class' => 'form-control select2' ]); ?>

                                       
                                    </div>
                          </div>
						  
						   <div class="col-md-3">
                                   <div class="form-group">
                                        <label for="name">Turnover</label>
										 <?php echo Form::select('turnover', $incomegroup, request()->get('turnover') ? request()->get('turnover') : '' , ['placeholder' => 'Pick Turnover','class' => 'form-control select2']); ?>

                                       
                                    </div>
                          </div>
						   
						 
						</div>
						<div class="row ">
						 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('CrmData.create')): ?>
						 
						<div class="col-md-1 pull-right">
						  <a class="btn btn-info btn-sm pull-right mb5" href="<?php echo e(URL::route('CrmData.create')); ?>"  ><i class="fa fa-plus-circle"></i> Add New</a>
						 </div>
						 <?php endif; ?>
						
						 <div class="col-md-1 pull-right">
						  
						 <button type="submit" class="btn btn-info pull-right "><i class="fa fa-search"></i>Search</button>
						 
						 </div>
						 
						  <div class="col-md-1 pull-right">
						  <a href="<?php echo e(URL::route('CrmData.list')); ?>" class="btn btn-default">Reset</a>
						 </div>
						   </div>
						<?php echo Form::close(); ?>

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body margin-top-20">
                        <div class="table-responsive">
                        <table id="listDataTable" class="table table-bordered table-striped list_view_table display responsive no-wrap" width="100%">
                            <thead>
                            <tr>
                                <th width="5%"><input type="checkbox" class="checkbox tableCheckedAll">  </th>
                                <th width="15%" style="text-align:left">Unique Code Contacts</th>
                                <th width="15%" style="text-align:left">Partner Name</th>
								<th width="15%" style="text-align:left">Pcdcid</th>
								<th width="10%" style="text-align:left">Full Name</th>
								<th width="15%" style="text-align:left">Industry Vertical</th>
								<th width="10%" style="text-align:left">Date</th>
                                <th class="notexport" width="15%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
                                <tr>
								<td> <input type="checkbox" class="checkbox rowCheckedAll"></td>
                                    <td style="text-align:left"><?php echo e($row->unique_code_contacts); ?></td>
                                     <td style="text-align:left"><?php echo e($row->partner_name); ?></td>
									  <td style="text-align:left"><?php echo e($row->pcdcid); ?></td>
									  <td style="text-align:left"><?php echo e($row->first_name); ?> <?php echo e($row->last_name); ?></td>
									  <td style="text-align:left"><?php echo e($row->industry ? $row->industry->name : ''); ?></td>
									  <td style="text-align:left"><?php echo e($row->created_at); ?></td>
                                    <td>
									   
									    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('CrmData.edit')): ?>
                                        <div class="btn-group">
										 <a title="Edit Industry"  href="<?php echo e(URL::route('CrmData.edit', $row->id)); ?>" class="btn btn-info btn-sm delete-industry"><i class="fa fa-fw fa-edit"></i></a>
                                            </a>
                                        </div>
										<?php endif; ?>
										 
										 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('CrmData.destroy')): ?>
                                        <div class="btn-group">
										 <a title="Delete Industry" href="javascript:void(0)" data-url="<?php echo e(URL::route('CrmData.destroy', $row->id)); ?>" class="btn btn-danger btn-sm delete-crmdata"><i class="fa fa-fw fa-trash"></i></a>
                                            </a>
                                        </div>
										<?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>
                            <tr>
                                <th width="5%"></th>
                                <th width="15%" style="text-align:left">Unique Code Contacts</th>
                                <th width="15%" style="text-align:left">Partner Name</th>
								<th width="15%" style="text-align:left">Pcdcid</th>
								<th width="10%" style="text-align:left">Organization Name</th>
								<th width="15%" style="text-align:left">Industry Vertical</th>
								<th width="10%" style="text-align:left">Date</th>
                                <th class="notexport" width="15%">Action</th>
                            </tr>
                            </tfoot>
                        </table>
						<?php echo e($results->links()); ?>

                    </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
        </div>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<!-- END PAGE CONTENT-->


<!-- BEGIN PAGE JS-->
<?php $__env->startSection('extraScript'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
           Crmdata.Init();
        });

    </script>
<?php $__env->stopSection(); ?>
<!-- END PAGE JS-->

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/crmdata/list.blade.php ENDPATH**/ ?>