<!-- Master page  -->


<!-- Page title -->
<?php $__env->startSection('pageTitle'); ?> Dashboard <?php $__env->stopSection(); ?>
<!-- End block -->
<?php $__env->startSection('extraStyle'); ?>
    <style>
        .notification li {
            font-size: 16px;
        }
        .notification li.info span.badge {
            background: #00c0ef;
        }
        .notification li.warning span.badge {
            background: #f39c12;
        }
        .notification li.success span.badge {
            background: #00a65a;
        }
        .notification li.error span.badge {
            background: #dd4b39;
        }
        .total_bal {
            margin-top: 5px;
            margin-right: 5%;
        }
    </style>
<?php $__env->stopSection(); ?>
<!-- BEGIN PAGE CONTENT-->
<?php $__env->startSection('pageContent'); ?>
    <!-- Main content -->
    <section class="content">
        <?php if($userRoleId == AppHelper::USER_ADMIN): ?>
            <div class="row">
                <div class="col-lg-3 col-xs-6">
                    <div class="small-box ">
                        <a class="small-box-footer bg-orange-dark" href="<?php echo e(URL::route('student.index')); ?>">
                            <div class="icon bg-orange-dark" style="padding: 9.5px 18px 8px 18px;">
                                <i class="fa icon-student"></i>
                            </div>
                            <div class="inner ">
                                <h3 class="text-white"><?php echo e($admin); ?> </h3>
                                <p class="text-white">
                                    Admin </p>
                            </div>
                        </a>
                    </div>
                </div>


                <div class="col-lg-3 col-xs-6">
                    <div class="small-box ">
                        <a class="small-box-footer bg-teal-light" href="<?php echo e(URL::route('academic.subject')); ?>">
                            <div class="icon bg-teal-light" style="padding: 9.5px 18px 8px 18px;">
                                <i class="fa icon-subject"></i>
                            </div>
                            <div class="inner ">
                                <h3 class="text-white">
                                    <?php echo e($partner); ?> </h3>
                                <p class="text-white">
                                    Partner </p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

       


    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<!-- END PAGE CONTENT-->

<!-- BEGIN PAGE JS-->
<?php $__env->startSection('extraScript'); ?>
   

<?php $__env->stopSection(); ?>
<!-- END PAGE JS-->

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\basic\resources\views/backend/user/dashboard.blade.php ENDPATH**/ ?>