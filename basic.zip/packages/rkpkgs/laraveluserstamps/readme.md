# Laravel Userstamps

Laravel Userstamps is a simple Laravel package for your Eloquent Model user specific feilds.
This package automatically inserts/updates an user id on your table on who created, last updated and deleted the record.

## Install
1. Add repositories in composer.json
